#include<stdio.h>
int main()
{
	printf("How do you do?\n");

}
