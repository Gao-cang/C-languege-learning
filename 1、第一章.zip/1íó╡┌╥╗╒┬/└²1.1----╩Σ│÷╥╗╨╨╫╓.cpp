#include<stdio.h>
int main()
{
	printf("This is a C program.\n");
	return 0;
}
