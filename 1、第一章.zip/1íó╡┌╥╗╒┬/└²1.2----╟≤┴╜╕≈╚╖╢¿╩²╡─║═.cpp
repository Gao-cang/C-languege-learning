#include<stdio.h>
int main()
{
	int a,b,sum;
	a=123;
	b=456;
	sum=a+b;
	printf("sum is %d\n",sum);
	return 0;
}
