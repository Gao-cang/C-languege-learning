#include<stdio.h>
int main()
{
	printf("Very good!\n");
	return 0;
 } 
